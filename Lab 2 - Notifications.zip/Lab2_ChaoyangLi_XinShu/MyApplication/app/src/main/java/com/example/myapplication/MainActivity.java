package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView mLv1;
    final int notifyID = 0x123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //list view
        mLv1 = findViewById(R.id.lv_1);
        mLv1.setAdapter(new MyListAdapter(MainActivity.this));
        mLv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                Notification.Builder notification = new Notification.Builder(MainActivity.this);
                notification.setAutoCancel(true);
                notification.setSmallIcon(R.drawable.ic_launcher_background);
                notification.setWhen(System.currentTimeMillis());
                notification.setContentTitle("Click Notification");
                notification.setContentText("Item " + position + " have been clicked!");

                NotificationChannel channel = new NotificationChannel("1","my_channel", NotificationManager.IMPORTANCE_DEFAULT);
                channel.enableLights(true);
                channel.setLightColor(Color.green(1));
                channel.setShowBadge(true);
                notificationManager.createNotificationChannel(channel);
                notification.setChannelId("1");

                notificationManager.notify(notifyID, notification.build());
            }
        });
    }

    //create menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = new MenuInflater(this);
        menuInflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //override onOptionsItemSelected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sendSMS:
                Intent intentSMS = new Intent(MainActivity.this, SendSmsActivity.class);
                startActivity(intentSMS);
                break;
            case R.id.sendEmail:
                Intent intentEmail = new Intent(MainActivity.this, SendEmailActivity.class);
                startActivity(intentEmail);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}

