package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class SendSmsActivity extends AppCompatActivity {
    EditText numberET,contentET;//numberEditText,contentEditText
    Button send;
    SmsManager sManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sms);

        // get SmsManager
        sManager = SmsManager.getDefault();

        numberET = (EditText) findViewById(R.id.number);
        contentET = (EditText) findViewById(R.id.content);
        send = (Button) findViewById(R.id.send);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = numberET.getText().toString();
                String context = contentET.getText().toString();
                ArrayList<String> list = sManager.divideMessage(context);

                //divide long text
                for(String text:list)
                {
                    sManager.sendTextMessage(phone,null,text,null,null);
                }

                Toast.makeText(getApplicationContext(),"Send Succeed",Toast.LENGTH_SHORT).show();
            }
        });
    }
}