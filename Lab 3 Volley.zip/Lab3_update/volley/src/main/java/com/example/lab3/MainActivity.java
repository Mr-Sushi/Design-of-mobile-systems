package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private Button insertButton,updateButton,searchButton,deleteButton,databaseButton;
    private EditText name,age;
    private TextView show,showAge;
    final DatabaseHlper dbHelper=new DatabaseHlper(MainActivity.this,"Test2.db",null,1);
    final int NOTIFYID=0x123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        insertButton=findViewById(R.id.btn_insert);
        updateButton=findViewById(R.id.btn_update);
        searchButton=findViewById(R.id.btn_search);
        deleteButton=findViewById(R.id.btn_delete);
        name=findViewById(R.id.name);
        age=findViewById(R.id.age);
        show=findViewById(R.id.tv_show);
        show.setMovementMethod(ScrollingMovementMethod.getInstance());
        showAge=findViewById(R.id.tv_showAge);
        showAge.setMovementMethod(ScrollingMovementMethod.getInstance());
        databaseButton=findViewById(R.id.Insert_da);



        SQLiteDatabase db=dbHelper.getReadableDatabase();

        myShow();
        databaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                json();
            }
        });



        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insert();


            }
        });
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SQLiteDatabase db=dbHelper.getWritableDatabase();
                ContentValues values=new ContentValues();
                values.put("email",age.getText().toString());
                db.update("information",values,"name=?",new String[]{name.getText().toString()});

                myShow();
                db.close();


                Log.d("myDebug","update");
                name.setText(null);
                age.setText(null);
            }
        });
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SQLiteDatabase db=dbHelper.getWritableDatabase();
                String name1=name.getText().toString();
                show.setText(null);
                if(name1.equals("")){

                    myShow();

                    db.close();
                }else {
                    show.setText("name");
                    showAge.setText("email");
                    Cursor cursor = db.rawQuery("select * from information where name = ? ", new String[]{name1});

                    while (cursor.moveToNext()) {
                        String newName = cursor.getString(cursor.getColumnIndex("name"));
                        String newAge = cursor.getString(cursor.getColumnIndex("email"));
                        show.setText(show.getText() + "\n" + newName);
                        showAge.setText(showAge.getText()+"\n" + newAge);
                    }

                    cursor.close();
                    db.close();
                    name.setText(null);
                    age.setText(null);
                }
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SQLiteDatabase db=dbHelper.getWritableDatabase();
                db.delete("information","name=?",new String[]{name.getText().toString()});
                Cursor cursor = db.rawQuery("select * from information",null);//获取表中的内容

                while (cursor.moveToNext()) {
                    String newName = cursor.getString(cursor.getColumnIndex("name"));
                    db.delete("information","name=?",new String[]{newName});
                }
                cursor.close();

                myShow();


                db.close();
                Log.d("myDeBug","DeleteSuccess");
                name.setText(null);
                age.setText(null);
            }
        });

    }

    public void myShow(){
        SQLiteDatabase db=dbHelper.getReadableDatabase();


        show.setText("name");
        showAge.setText("email");
        Cursor cursor = db.rawQuery("select * from information",null);//获取表中的内容

        while (cursor.moveToNext()) {
            String newName = cursor.getString(cursor.getColumnIndex("name"));
          String newAge = cursor.getString(cursor.getColumnIndex("email"));
            show.setText(show.getText() + "\n" + newName);
            showAge.setText(showAge.getText()+"\n" + newAge);
        }
        cursor.close();
    }
    public void insert(){
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("name",name.getText().toString());
        values.put("email",age.getText().toString());
        long id =db.insert("information",null,values);//把数据插入表中


        myShow();
        //notification
        final String CHANNEL_ID = "channel_id_1";
        final String CHANNEL_NAME = "channel_name_1";
        NotificationManager mNotificationManager = (NotificationManager)
                getSystemService(Context.NOTIFICATION_SERVICE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            //只在Android8.O之上需要渠道
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID,
                    CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            //如果这里用IMPORTANCE_NOENE就需要在系统的设置里面开启渠道，
            //通知才能正常弹出
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder builder= new NotificationCompat.Builder(MainActivity.this,CHANNEL_ID);
        builder.setContentTitle("The title")
                .setContentText("Insert Successfully")
                .setSmallIcon(R.drawable.p8)
                .setAutoCancel(true);
        mNotificationManager.notify(NOTIFYID, builder.build());


        db.close();
        name.setText(null);
        age.setText(null);
    }
    public void json(){
        final RequestQueue queue;
        queue = Volley.newRequestQueue(this);

        String jsonRUL = "https://jsonplaceholder.typicode.com/users";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, jsonRUL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject userJsonObject = response.getJSONObject(i);
                                SQLiteDatabase db=dbHelper.getWritableDatabase();
                                ContentValues values=new ContentValues();
                                values.put("name",userJsonObject.getString("name"));
                                values.put("email",userJsonObject.getString("email"));
                                long id =db.insert("information",null,values);//把数据插入表中


                                myShow();
                                db.close();
                                name.setText(null);
                                age.setText(null);
//                                names.append(userJsonObject.getString("name"));
//                                names.append("  --  " + userJsonObject.getString("email"));
//                                names.append("\n");

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //setProgressBar.setVisibility(View.INVISIBLE);
            }
        });

        queue.add(jsonArrayRequest);

    }
}
